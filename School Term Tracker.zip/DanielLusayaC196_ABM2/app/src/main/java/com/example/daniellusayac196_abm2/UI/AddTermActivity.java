package com.example.daniellusayac196_abm2.UI;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.DatePicker;
import android.widget.EditText;

import com.example.daniellusayac196_abm2.ClassEntities.CourseEntity;
import com.example.daniellusayac196_abm2.ClassEntities.TermEntity;
import com.example.daniellusayac196_abm2.Database.SchedulingManagementRepository;
import com.example.daniellusayac196_abm2.R;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;

public class AddTermActivity extends AppCompatActivity {
    private SchedulingManagementRepository schedulingManagementRepository;
    int Id;

    String title;
    String startDate;
    String endDate;

    EditText editTitle;
    EditText editStartDate;
    EditText editEndDate;

    TermEntity currentTerm;

    Calendar calendarStart = Calendar.getInstance();
    Calendar calendarEnd = Calendar.getInstance();
    DatePickerDialog.OnDateSetListener myStartDate;
    DatePickerDialog.OnDateSetListener myEndDate;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_term);
        Id=getIntent().getIntExtra("termID",-1);
        if (Id==-1)
            Id=CourseDetail.id2;
        schedulingManagementRepository= new SchedulingManagementRepository(getApplication());
        List<TermEntity> allTerms=schedulingManagementRepository.getAllTerms();

        for(TermEntity t:allTerms){
            if(t.getId()==Id)
                currentTerm=t;
        }
        editTitle=findViewById(R.id.termTitle);
        editStartDate=findViewById(R.id.termStartDate);
        editEndDate =findViewById(R.id.termEndDate);

        if(currentTerm!=null){
            title=currentTerm.getTitle();
            startDate=currentTerm.getStartDate();
            endDate=currentTerm.getEndDate();
        }

        if(Id!=-1){
            editTitle.setText(title);
            editStartDate.setText(startDate);
            editEndDate.setText(endDate);
        }
        schedulingManagementRepository = new SchedulingManagementRepository(getApplication());

        myStartDate = new DatePickerDialog.OnDateSetListener() {

            @Override
            public void onDateSet(DatePicker view, int year, int monthOfYear,
                                  int dayOfMonth) {
                // TODO Auto-generated method stub
                calendarStart.set(Calendar.YEAR, year);
                calendarStart.set(Calendar.MONTH, monthOfYear);
                calendarStart.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                String myFormat = "MM/dd/yy"; //In which you need put here
                SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);

                updateStartDateLabel();
            }

        };
        editStartDate.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                new DatePickerDialog(AddTermActivity.this, myStartDate, calendarStart
                        .get(Calendar.YEAR), calendarStart.get(Calendar.MONTH),
                        calendarStart.get(Calendar.DAY_OF_MONTH)).show();
            }
        });

        myEndDate = new DatePickerDialog.OnDateSetListener() {

            @Override
            public void onDateSet(DatePicker view, int year, int monthOfYear,
                                  int dayOfMonth) {
                // TODO Auto-generated method stub
                calendarEnd.set(Calendar.YEAR, year);
                calendarEnd.set(Calendar.MONTH, monthOfYear);
                calendarEnd.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                String myFormat = "MM/dd/yy"; //In which you need put here
                SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);

                updateEndDateLabel();
            }

        };
        editEndDate.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                new DatePickerDialog(AddTermActivity.this, myEndDate, calendarEnd
                        .get(Calendar.YEAR), calendarEnd.get(Calendar.MONTH),
                        calendarEnd.get(Calendar.DAY_OF_MONTH)).show();
            }
        });

    }

    private void updateEndDateLabel() {
        String myFormat = "MM/dd/yy";
        SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);

        editEndDate.setText(sdf.format(calendarEnd.getTime()));
    }

    private void updateStartDateLabel() {
        String myFormat = "MM/dd/yy";
        SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);

        editStartDate.setText(sdf.format(calendarStart.getTime()));
    }

    public void addTermFromScreen(View view) {
        TermEntity t;

        if(Id!=-1)
            t = new TermEntity(Id,editTitle.getText().toString(),editStartDate.getText().toString(),editEndDate.getText().toString());
        else{
            List<TermEntity> allTerms=schedulingManagementRepository.getAllTerms();
            Id=allTerms.get(allTerms.size()-1).getId();
            t = new TermEntity(++Id,editTitle.getText().toString(),editStartDate.getText().toString(),editEndDate.getText().toString());
        }
        schedulingManagementRepository.insert(t);
        Intent intent=new Intent(com.example.daniellusayac196_abm2.UI.AddTermActivity.this,TermActivity.class);
        startActivity(intent);

    }
}

