package com.example.daniellusayac196_abm2.UI;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.AlarmManager;
import android.app.DatePickerDialog;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Toast;

import com.example.daniellusayac196_abm2.ClassEntities.AssessmentEntity;
import com.example.daniellusayac196_abm2.ClassEntities.CourseEntity;
import com.example.daniellusayac196_abm2.Database.SchedulingManagementRepository;
import com.example.daniellusayac196_abm2.R;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;

public class AddCourseActivity extends AppCompatActivity {
    private SchedulingManagementRepository schedulingManagementRepository;
    static int id2;
    int id;
    int termID;
    String title;
    String startDate;
    String endDate;
    String status;
    String instructorName;
    String instructorPhone;
    String instructorEmail;
    String notes;
    EditText editTitle;
    EditText editStartDate;
    EditText editEndDate;
    EditText editStatus;
    EditText editInstructorName;
    EditText editInstructorPhone;
    EditText editInstructorEmail;
    EditText editNotes;
    List<AssessmentEntity> filteredAssessments = new ArrayList<>();
    CourseEntity currentCourse;

    Calendar calendarStart = Calendar.getInstance();
    Calendar calendarEnd = Calendar.getInstance();
    DatePickerDialog.OnDateSetListener myStartDate;
    DatePickerDialog.OnDateSetListener myEndDate;
    Long startDateLong;
    Long endDateLong;
    public static int numAlert;


    public static int numberOfAssessments;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_course);
        id = getIntent().getIntExtra("courseID", -1);
        title = getIntent().getStringExtra("courseTitle");
        startDate = getIntent().getStringExtra("courseStartDate");
        endDate = getIntent().getStringExtra("courseEndDate");
        status = getIntent().getStringExtra("courseStatus");
        instructorName = getIntent().getStringExtra("instructorName");
        instructorPhone = getIntent().getStringExtra("instructorPhone");
        instructorEmail = getIntent().getStringExtra("instructorEmail");
        notes = getIntent().getStringExtra("notes");
        termID = getIntent().getIntExtra("termID", -1);
        id2 = termID;
        String termIDString = String.valueOf(termID);
        editTitle = findViewById(R.id.courseTitle);
        editStartDate = findViewById(R.id.courseStartDate);
        editEndDate = findViewById(R.id.courseEndDate);
        editStatus = findViewById(R.id.courseStatus);
        editInstructorName = findViewById(R.id.courseInstructorName);
        editInstructorPhone = findViewById(R.id.courseInstructorPhone);
        editInstructorEmail = findViewById(R.id.courseInstructorEmail);
        editNotes = findViewById(R.id.courseNotes);
        if (id != -1) {
            editTitle.setText(title);
            editStartDate.setText(startDate);
            editEndDate.setText(endDate);
            editStatus.setText(status);
            editInstructorName.setText(instructorName);
            editInstructorPhone.setText(instructorPhone);
            editInstructorEmail.setText(instructorEmail);
            editNotes.setText(notes);


        }
        schedulingManagementRepository = new SchedulingManagementRepository(getApplication());

        myStartDate = new DatePickerDialog.OnDateSetListener() {

            @Override
            public void onDateSet(DatePicker view, int year, int monthOfYear,
                                  int dayOfMonth) {
                calendarStart.set(Calendar.YEAR, year);
                calendarStart.set(Calendar.MONTH, monthOfYear);
                calendarStart.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                String myFormat = "MM/dd/yy";
                SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);

                updateStartDateLabel();
            }

        };
        editStartDate.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                new DatePickerDialog(AddCourseActivity.this, myStartDate, calendarStart
                        .get(Calendar.YEAR), calendarStart.get(Calendar.MONTH),
                        calendarStart.get(Calendar.DAY_OF_MONTH)).show();
            }
        });

        myEndDate = new DatePickerDialog.OnDateSetListener() {

            @Override
            public void onDateSet(DatePicker view, int year, int monthOfYear,
                                  int dayOfMonth) {
                calendarEnd.set(Calendar.YEAR, year);
                calendarEnd.set(Calendar.MONTH, monthOfYear);
                calendarEnd.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                String myFormat = "MM/dd/yy"; //In which you need put here
                SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);

                updateEndDateLabel();
            }

        };
        editEndDate.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                new DatePickerDialog(AddCourseActivity.this, myEndDate, calendarEnd
                        .get(Calendar.YEAR), calendarEnd.get(Calendar.MONTH),
                        calendarEnd.get(Calendar.DAY_OF_MONTH)).show();
            }
        });

        List<CourseEntity> allCourses = schedulingManagementRepository.getAllCourses();

        for (CourseEntity c : allCourses) {
            if (c.getId() == id)
                currentCourse = c;
        }

        if (currentCourse != null) {
            title = currentCourse.getTitle();
            startDate = currentCourse.getStartDate();
            endDate = currentCourse.getEndDate();
            status = currentCourse.getStatus();
            instructorName = currentCourse.getInstructorName();
            instructorPhone = currentCourse.getInstructorPhone();
            instructorEmail = currentCourse.getInstructorEmail();
            notes = currentCourse.getNotes();
        }

        schedulingManagementRepository = new SchedulingManagementRepository(getApplication());

    }

    private void updateEndDateLabel() {
        String myFormat = "MM/dd/yy";
        SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);

        editEndDate.setText(sdf.format(calendarEnd.getTime()));
    }

    private void updateStartDateLabel() {
        String myFormat = "MM/dd/yy";
        SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);

        editStartDate.setText(sdf.format(calendarStart.getTime()));
    }

    public void addCourseToTerm(View view) {
        CourseEntity t;

        if (id != -1)
            t = new CourseEntity(id, termID, editTitle.getText().toString(), editStartDate.getText().toString(),
                    editEndDate.getText().toString(), editStatus.getText().toString(), editInstructorName.getText().toString(),
                    editInstructorPhone.getText().toString(), editInstructorEmail.getText().toString(), editNotes.getText().toString());
        else {
            List<CourseEntity> allCourses = schedulingManagementRepository.getAllCourses();
            id = allCourses.get(allCourses.size() - 1).getId();

            t = new CourseEntity(++id, termID, editTitle.getText().toString(), editStartDate.getText().toString(),
                    editEndDate.getText().toString(), editStatus.getText().toString(), editInstructorName.getText().toString(),
                    editInstructorPhone.getText().toString(), editInstructorEmail.getText().toString(), editNotes.getText().toString());
        }
        schedulingManagementRepository.insert(t);
        Intent intent = new Intent(AddCourseActivity.this, TermActivity.class);
        startActivity(intent);
    }

}