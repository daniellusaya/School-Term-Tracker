package com.example.daniellusayac196_abm2.UI;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.daniellusayac196_abm2.Database.SchedulingManagementRepository;
import com.example.daniellusayac196_abm2.R;

public class TermActivity extends AppCompatActivity {
private SchedulingManagementRepository schedulingManagementRepository;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        CourseDetail.id2=-1;
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_term);
        schedulingManagementRepository = new SchedulingManagementRepository(getApplication());
        schedulingManagementRepository.getAllTerms();
        RecyclerView recyclerView = findViewById(R.id.term_recyclerview);

        final TermAdapter adapter = new TermAdapter(this);
        recyclerView.setAdapter(adapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter.setWords(schedulingManagementRepository.getAllTerms());


    }

    public void addTerm(View view) {
        Intent intent= new Intent(TermActivity.this, AddTermActivity.class);
        startActivity(intent);
    }
}