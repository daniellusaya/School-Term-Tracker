package com.example.daniellusayac196_abm2.Database;

import android.content.Context;


import androidx.annotation.NonNull;
import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;
import androidx.sqlite.db.SupportSQLiteDatabase;

import com.example.daniellusayac196_abm2.ClassEntities.AssessmentEntity;
import com.example.daniellusayac196_abm2.ClassEntities.CourseEntity;
import com.example.daniellusayac196_abm2.ClassEntities.TermEntity;
import com.example.daniellusayac196_abm2.DAO.AssessmentDAO;
import com.example.daniellusayac196_abm2.DAO.CourseDAO;
import com.example.daniellusayac196_abm2.DAO.TermDAO;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

@Database(entities = {TermEntity.class, CourseEntity.class, AssessmentEntity.class}, version = 5)
public abstract class SchedulingManagementDatabase extends RoomDatabase {
    public abstract TermDAO termDAO();
    public abstract CourseDAO courseDAO();
    public abstract AssessmentDAO assessmentDAO();
    private static final int NUMBER_OF_THREADS = 4;

    static final ExecutorService databaseWriteExecutor =
            Executors.newFixedThreadPool(NUMBER_OF_THREADS);

    private static volatile SchedulingManagementDatabase INSTANCE;

    static SchedulingManagementDatabase getDatabase(final Context context) {
        if (INSTANCE == null) {
            synchronized (SchedulingManagementDatabase.class) {
                if (INSTANCE == null) {
                    INSTANCE = Room.databaseBuilder(context.getApplicationContext(), SchedulingManagementDatabase.class, "scheduling_management_database.db")
                            .fallbackToDestructiveMigration()
                            .addCallback(roomDatabaseCallback)
                            .build();
                }
            }
        }
        return INSTANCE;
    }
    private static Callback roomDatabaseCallback = new Callback() {

        @Override
        public void onOpen(@NonNull SupportSQLiteDatabase db) {
            super.onOpen(db);

            databaseWriteExecutor.execute(() -> {

                CourseDAO courseDAO = INSTANCE.courseDAO();
                TermDAO termDAO = INSTANCE.termDAO();
                AssessmentDAO assessmentDAO = INSTANCE.assessmentDAO();

                //termDAO.deleteAllTerms();
                //courseDAO.deleteAllCourses();

                CourseEntity course = new CourseEntity(1,1 ,"Mobile Application", "01/01/22", "02/01/22","active","Miss Smartie","22222222",
                        "smartie@gmail.com","Long Class");
                courseDAO.insert(course);

                CourseEntity course2 = new CourseEntity(2,1 ,"Java 2", "02/01/22", "03/01/22","complete","Miss Smartie","22222222",
                        "smartie@gmail.com","Long Class");
                courseDAO.insert(course2);

                CourseEntity course3 = new CourseEntity(3,1, "Java 1", "03/01/22", "04/01/22","complete","Miss Smartie","22222222",
                        "smartie@gmail.com","Long Class");
                courseDAO.insert(course3);

                CourseEntity course4 = new CourseEntity(4,2, "Capstone", "04/01/23", "05/01/23","scheduled","Miss Smartie","22222222",
                        "smartie@gmail.com","Long Class");
                courseDAO.insert(course4);

                CourseEntity course5 = new CourseEntity(5,2, "Software Engineering", "05/01/23", "06/01/23","active","Miss Smartie","22222222",
                        "smartie@gmail.com","Long Class");
                courseDAO.insert(course5);

                CourseEntity course6 = new CourseEntity(6,2, "Java 3", "06/01/23", "07/01/23","complete","Miss Smartie","22222222",
                        "smartie@gmail.com","Long Class");
                courseDAO.insert(course6);

                CourseEntity course7 = new CourseEntity(7,3, "Java 4", "07/01/24", "08/01/24","complete","Miss Smartie","22222222",
                        "smartie@gmail.com","Long Class");
                courseDAO.insert(course7);

                CourseEntity course8 = new CourseEntity(8,3, "C#", "08/01/24", "09/01/24","scheduled","Miss Smartie","22222222",
                        "smartie@gmail.com","Long Class");
                courseDAO.insert(course8);


                TermEntity term = new TermEntity(1, "Winter Term", "2022","2023");
                termDAO.insert(term);


                TermEntity term2 = new TermEntity(2, "Spring Term","2023","2024");
                termDAO.insert(term2);

                TermEntity term3 = new TermEntity(3, "Fall Term","2024","2025");
                termDAO.insert(term3);

                AssessmentEntity assessment = new AssessmentEntity(1,"JYM1","01/15/22", "OA", 1);
                assessmentDAO.insert(assessment);
                AssessmentEntity assessment1 = new AssessmentEntity(2,"Cert","02/15/22", "OA",2);
                assessmentDAO.insert(assessment1);
                AssessmentEntity assessment2 = new AssessmentEntity(3,"LVM3","03/15/22", "OA",3);
                assessmentDAO.insert(assessment2);
                AssessmentEntity assessment3 = new AssessmentEntity(4,"Cert","04/15/23", "OA",4);
                assessmentDAO.insert(assessment3);
                AssessmentEntity assessment4 = new AssessmentEntity(5,"ABM2","05/15/23", "PA",5);
                assessmentDAO.insert(assessment4);
                AssessmentEntity assessment5 = new AssessmentEntity(6,"ABC5","06/15/23", "PA",6);
                assessmentDAO.insert(assessment5);
                AssessmentEntity assessment6 = new AssessmentEntity(7,"Project","07/15/24", "PA",7);
                assessmentDAO.insert(assessment6);
                AssessmentEntity assessment7 = new AssessmentEntity(8,"Exam","08/15/24", "OA",8);
                assessmentDAO.insert(assessment7);
            });
        }
    };
}
