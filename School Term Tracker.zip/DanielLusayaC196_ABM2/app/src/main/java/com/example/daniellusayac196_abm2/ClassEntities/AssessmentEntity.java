package com.example.daniellusayac196_abm2.ClassEntities;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName= "Assessment_Table")
public class AssessmentEntity {

    @PrimaryKey
    private int id;

    @ColumnInfo(name = "Title")
    private String title;

    @ColumnInfo(name = "End_Date")
    private String endDate;

    @ColumnInfo(name = "Type")
    private String type;

    @ColumnInfo(name = "Course_ID")
    private int courseID;

    @Override
    public String toString() {
        return "AssessmentEntity{" +
                "id=" + id +
                ", title='" + title + '\'' +
                ", endDate=" + endDate +
                ", type=" + type +
                ", courseID=" + courseID +
                '}';
    }
    public AssessmentEntity(int id, String title, String endDate, String type, int courseID) {
        this.id=id;
        this.title = title;
        this.endDate = endDate;
        this.type = type;
        this.courseID=courseID;

    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getEndDate() {
        return endDate;
    }

    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }

    public String getType() { return type; }

    public void setType(String type) { this.type = type; }

    public int getCourseID() {
        return courseID;
    }

    public void setCourseID(int courseID) {
        this.courseID = courseID;
    }
}
