package com.example.daniellusayac196_abm2.UI;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.example.daniellusayac196_abm2.ClassEntities.CourseEntity;
import com.example.daniellusayac196_abm2.R;

import java.util.List;

public class CourseAdapter extends RecyclerView.Adapter<CourseAdapter.CourseViewHolder>{

    class CourseViewHolder extends RecyclerView.ViewHolder {
        private final TextView courseItemViewName;
        private final TextView courseItemViewID;

        private CourseViewHolder(View itemView) {
            super(itemView);
            courseItemViewName = itemView.findViewById(R.id.text_view_title);
            courseItemViewID = itemView.findViewById(R.id.text_view_termID);
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    int position = getAdapterPosition();
                    final CourseEntity current = mCourses.get(position);
                    Intent intent = new Intent(context, CourseDetail.class);
                    intent.putExtra("courseTitle", current.getTitle());
                    intent.putExtra("courseID", current.getId());
                    intent.putExtra("termID", current.getTermID());
                    intent.putExtra("courseStartDate", current.getStartDate());
                    intent.putExtra("courseEndDate", current.getEndDate());
                    intent.putExtra("courseStatus", current.getStatus());
                    intent.putExtra("instructorName", current.getInstructorName());
                    intent.putExtra("instructorPhone", current.getInstructorPhone());
                    intent.putExtra("instructorEmail", current.getInstructorEmail());
                    intent.putExtra("notes", current.getNotes());
                    intent.putExtra("position", position);
                    context.startActivity(intent);
                }
            });
        }

    }
    private final LayoutInflater mInflater;
    private final Context context;
    private List<CourseEntity> mCourses;

    public CourseAdapter(Context context) {
        mInflater = LayoutInflater.from(context);
        this.context=context;
    }
    @Override
    public CourseViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = mInflater.inflate(R.layout.course_list_item, parent, false);

        return new CourseViewHolder(itemView);
    }
    @Override
    public void onBindViewHolder(CourseViewHolder holder, int position) {
        if (mCourses != null) {
            CourseEntity current = mCourses.get(position);
            holder.courseItemViewName.setText(current.getTitle());
            holder.courseItemViewID.setText(Integer.toString(current.getTermID()));
        } else {
            holder.courseItemViewID.setText("No Word");
            holder.courseItemViewName.setText("No Word");
        }

    }

    public void setWords(List<CourseEntity> words) {
        mCourses = words;
        notifyDataSetChanged();
    }

    @Override
    public int getItemCount() {
        if (mCourses != null)
            return mCourses.size();
        else return 0;
    }
}

