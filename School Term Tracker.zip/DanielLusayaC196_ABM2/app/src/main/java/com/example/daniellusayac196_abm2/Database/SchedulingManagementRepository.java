package com.example.daniellusayac196_abm2.Database;

import android.app.Application;


import com.example.daniellusayac196_abm2.ClassEntities.AssessmentEntity;
import com.example.daniellusayac196_abm2.ClassEntities.CourseEntity;
import com.example.daniellusayac196_abm2.ClassEntities.TermEntity;
import com.example.daniellusayac196_abm2.DAO.AssessmentDAO;
import com.example.daniellusayac196_abm2.DAO.CourseDAO;
import com.example.daniellusayac196_abm2.DAO.TermDAO;

import java.util.List;

public class SchedulingManagementRepository {
    private TermDAO termDAO;
    private CourseDAO courseDAO;
    private AssessmentDAO assessmentDAO;
    private List<TermEntity> allTerms;
    private List<CourseEntity> allCourses;
    private List<AssessmentEntity> allAssessments;
    private int termID;

    public SchedulingManagementRepository(Application application) {

        SchedulingManagementDatabase db = SchedulingManagementDatabase.getDatabase(application);
        termDAO = db.termDAO();
        courseDAO = db.courseDAO();
        assessmentDAO = db.assessmentDAO();

        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
    public List<CourseEntity> getAllCourses() {
        SchedulingManagementDatabase.databaseWriteExecutor.execute(()->{
            allCourses=courseDAO.getAllCourses();
        });
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return allCourses;
    }
    public List<TermEntity> getAllTerms() {
        SchedulingManagementDatabase.databaseWriteExecutor.execute(()->{
            allTerms=termDAO.getAllTerms();
        });
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return allTerms;
    }
    public List<AssessmentEntity> getAllAssessments() {
        SchedulingManagementDatabase.databaseWriteExecutor.execute(()->{
            allAssessments=assessmentDAO.getAllAssessments();
        });
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return allAssessments;
    }
    public void insert (TermEntity termEntity) {
        SchedulingManagementDatabase.databaseWriteExecutor.execute(() -> {
            termDAO.insert(termEntity);
        });try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
    public void insert (CourseEntity courseEntity){
        SchedulingManagementDatabase.databaseWriteExecutor.execute(()->{
            courseDAO.insert(courseEntity);
        });try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
    public void insert (AssessmentEntity assessmentEntity) {
        SchedulingManagementDatabase.databaseWriteExecutor.execute(() -> {
            assessmentDAO.insert(assessmentEntity);
        });try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
    public void delete (TermEntity termEntity){
        SchedulingManagementDatabase.databaseWriteExecutor.execute(()->{
            termDAO.delete(termEntity);
        });try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
    public void delete (CourseEntity courseEntity){
        SchedulingManagementDatabase.databaseWriteExecutor.execute(()->{
            courseDAO.delete(courseEntity);
        });try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
    public void delete (AssessmentEntity assessmentEntity){
        SchedulingManagementDatabase.databaseWriteExecutor.execute(()->{
            assessmentDAO.delete(assessmentEntity);
        });try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

}
