package com.example.daniellusayac196_abm2.UI;

import android.app.AlarmManager;
import android.app.DatePickerDialog;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.DatePicker;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

import com.example.daniellusayac196_abm2.ClassEntities.AssessmentEntity;
import com.example.daniellusayac196_abm2.ClassEntities.CourseEntity;
import com.example.daniellusayac196_abm2.Database.SchedulingManagementRepository;
import com.example.daniellusayac196_abm2.R;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;

public class AssessmentActivity extends AppCompatActivity{

    private SchedulingManagementRepository schedulingManagementRepository;
    static int id2;
    int id;
    int courseID;
    String title;
    String endDate;
    String type;
    EditText editTitle;
    EditText editEndDate;
    EditText editType;
    AssessmentEntity currentAssessment;

    Calendar calendarEnd = Calendar.getInstance();
    DatePickerDialog.OnDateSetListener myEndDate;
    Long endDateLong;
    public static int numAlert;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_assessment);
        id = getIntent().getIntExtra("assessmentID",-1);
        title=getIntent().getStringExtra("assessmentTitle");
        endDate=getIntent().getStringExtra("assessmentEndDate");
        type=getIntent().getStringExtra("assessmentType");
        courseID=getIntent().getIntExtra("courseID", -1);
        id2=courseID;
        String courseIDString = String.valueOf(courseID);
        editTitle=findViewById(R.id.assessmentTitle);
        editEndDate=findViewById(R.id.assessmentEndDate);
        editType=findViewById(R.id.assessmentType);

        if(id!=-1){
            editTitle.setText(title);
            editEndDate.setText(endDate);
            editType.setText(type);
        }
        schedulingManagementRepository= new SchedulingManagementRepository(getApplication());

        myEndDate = new DatePickerDialog.OnDateSetListener() {

            @Override
            public void onDateSet(DatePicker view, int year, int monthOfYear,
                                  int dayOfMonth) {
                // TODO Auto-generated method stub
                calendarEnd.set(Calendar.YEAR, year);
                calendarEnd.set(Calendar.MONTH, monthOfYear);
                calendarEnd.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                String myFormat = "MM/dd/yy"; //In which you need put here
                SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);

                updateEndDateLabel();
            }

        };


        editEndDate.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                new DatePickerDialog(AssessmentActivity.this, myEndDate, calendarEnd
                        .get(Calendar.YEAR), calendarEnd.get(Calendar.MONTH),
                        calendarEnd.get(Calendar.DAY_OF_MONTH)).show();
            }
        });

        List<AssessmentEntity> allAssessments = schedulingManagementRepository.getAllAssessments();

        for(AssessmentEntity a : allAssessments) {
            if(a.getId() == id)
                currentAssessment = a;
        }

        if(currentAssessment != null) {
            title = currentAssessment.getTitle();
            endDate = currentAssessment.getEndDate();
            type = currentAssessment.getType();
            courseID = currentAssessment.getCourseID();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.assessment_menu, menu);
        return true;
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.notifyEndDate) {
            Intent intent=new Intent(AssessmentActivity.this,MyReceiver.class);
            intent.putExtra("key","Notification for Assessment: " + currentAssessment.getTitle() + " with an End Date of: " + currentAssessment.getEndDate());
            PendingIntent sender= PendingIntent.getBroadcast(AssessmentActivity.this,++numAlert,intent,0);
            AlarmManager alarmManager=(AlarmManager)getSystemService(Context.ALARM_SERVICE);
            endDateLong=calendarEnd.getTimeInMillis();
            alarmManager.set(AlarmManager.RTC_WAKEUP, endDateLong, sender);
            System.out.println(endDateLong);
            return true;
        }
        if (id == R.id.deleteAssessment) {

            schedulingManagementRepository.delete(currentAssessment);
        }

        Intent intent=new Intent(AssessmentActivity.this,CourseActivity.class);
        startActivity(intent);
        return super.onOptionsItemSelected(item);

    }

    private void updateEndDateLabel() {
        String myFormat = "MM/dd/yy"; //In which you need put here
        SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);

        editEndDate.setText(sdf.format(calendarEnd.getTime()));
    }

    public void addAssessmentToCourse(View view) {
        AssessmentEntity t;

        if(id!=-1)
            t = new AssessmentEntity(id, editTitle.getText().toString(),
                    editEndDate.getText().toString(), editType.getText().toString(), courseID);
        else{
            List<AssessmentEntity> allAssessments=schedulingManagementRepository.getAllAssessments();
            id =allAssessments.get(allAssessments.size()-1).getId();

            t = new AssessmentEntity(++id, editTitle.getText().toString(),
                    editEndDate.getText().toString(), editType.getText().toString(), courseID);
        }
        schedulingManagementRepository.insert(t);
        Intent intent=new Intent(AssessmentActivity.this,CourseActivity.class);
        startActivity(intent);
    }

}
