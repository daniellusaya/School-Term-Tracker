package com.example.daniellusayac196_abm2.UI;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.example.daniellusayac196_abm2.ClassEntities.TermEntity;
import com.example.daniellusayac196_abm2.R;

import java.util.List;

public class TermAdapter extends RecyclerView.Adapter<TermAdapter.TermViewHolder> {


    class TermViewHolder extends RecyclerView.ViewHolder{
        private final TextView termTitleView;
        private final TextView termStartView;
        private final TextView termEndView;

        private TermViewHolder(View itemView){
            super(itemView);
            termTitleView= itemView.findViewById(R.id.text_view_title);
            termStartView= itemView.findViewById(R.id.text_view_start);
            termEndView= itemView.findViewById(R.id.text_view_end);
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    int position = getAdapterPosition();
                    final TermEntity current = mTerms.get(position);
                    Intent intent = new Intent(context, CourseActivity.class);
                    intent.putExtra("termTitle", current.getTitle());
                    intent.putExtra("termID", current.getId());
                    intent.putExtra("termStartDate", current.getStartDate());
                    intent.putExtra("termEndDate", current.getEndDate());
                    intent.putExtra("position", position);

                    context.startActivity(intent);


                }
            });
        }
    }
    private final LayoutInflater mInflater;
    private final Context context;
    private List<TermEntity> mTerms;

    public TermAdapter(Context context){
        mInflater=LayoutInflater.from(context);
        this.context = context;

    }

    @Override
    public TermViewHolder onCreateViewHolder(ViewGroup parent, int viewType){
        View itemView = mInflater.inflate(R.layout.term_list_item, parent, false);
        return new TermViewHolder(itemView);
    }
    @Override
    public void onBindViewHolder(TermViewHolder holder, int position) {

        if (mTerms != null) {
            final TermEntity current = mTerms.get(position);
            holder.termTitleView.setText(current.getTitle());
            holder.termStartView.setText(current.getStartDate());
            holder.termEndView.setText(current.getEndDate());

        } else {
            holder.termTitleView.setText("no title");
            holder.termStartView.setText("no start");
            holder.termEndView.setText("no end");
        }
    }

    @Override
    public int getItemCount() {
        if (mTerms != null)
            return mTerms.size();
        else return 0;
    }

    public void setWords(List<TermEntity> words) {
        mTerms = words;
        notifyDataSetChanged();
    }
}
