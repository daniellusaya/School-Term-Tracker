package com.example.daniellusayac196_abm2.UI;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.example.daniellusayac196_abm2.ClassEntities.AssessmentEntity;
import com.example.daniellusayac196_abm2.ClassEntities.CourseEntity;
import com.example.daniellusayac196_abm2.R;

import java.util.List;

public class AssessmentAdapter extends RecyclerView.Adapter<AssessmentAdapter.AssessmentViewHolder>{

    class AssessmentViewHolder extends RecyclerView.ViewHolder {
        private final TextView assessmentItemViewName;
        private final TextView assessmentItemViewID;

        private AssessmentViewHolder(View itemView) {
            super(itemView);
            assessmentItemViewName = itemView.findViewById(R.id.text_view_title);
            assessmentItemViewID = itemView.findViewById(R.id.text_view_courseID);
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    int position = getAdapterPosition();
                    final AssessmentEntity current = mAssessments.get(position);
                    Intent intent = new Intent(context, AssessmentActivity.class);
                    intent.putExtra("assessmentTitle", current.getTitle());
                    intent.putExtra("assessmentID", current.getId());
                    intent.putExtra("courseID", current.getCourseID());
                    intent.putExtra("assessmentEndDate", current.getEndDate());
                    intent.putExtra("assessmentType", current.getType());
                    intent.putExtra("position", position);
                    context.startActivity(intent);
                }
            });
        }

    }
    private final LayoutInflater mInflater;
    private final Context context;
    private List<AssessmentEntity> mAssessments; // Cached copy of words

    public AssessmentAdapter(Context context) {
        mInflater = LayoutInflater.from(context);
        this.context=context;
    }
    @Override
    public AssessmentViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = mInflater.inflate(R.layout.assessment_list_item, parent, false);

        return new AssessmentViewHolder(itemView);
    }
    @Override
    public void onBindViewHolder(AssessmentViewHolder holder, int position) {
        if (mAssessments != null) {
            AssessmentEntity current = mAssessments.get(position);
            holder.assessmentItemViewName.setText(current.getTitle());
            holder.assessmentItemViewID.setText(Integer.toString(current.getCourseID()));
        } else {
            // Covers the case of data not being ready yet.
            holder.assessmentItemViewID.setText("No Word");
            holder.assessmentItemViewName.setText("No Word");
        }

    }

    public void setWords(List<AssessmentEntity> words) {
        mAssessments = words;
        notifyDataSetChanged();
    }

    @Override
    public int getItemCount() {
        if (mAssessments != null)
            return mAssessments.size();
        else return 0;
    }
}
