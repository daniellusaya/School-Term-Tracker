package com.example.daniellusayac196_abm2.DAO;


import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;

import com.example.daniellusayac196_abm2.ClassEntities.CourseEntity;

import java.util.List;

//queries are stored in the dao interface
@Dao
public interface CourseDAO {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void insert(CourseEntity course);
    @Delete
    void delete(CourseEntity course);

    @Query("DELETE FROM course_table")
    void deleteAllCourses();

    @Query("SELECT * FROM course_table ORDER BY id ASC")
    List<CourseEntity> getAllCourses();
}
